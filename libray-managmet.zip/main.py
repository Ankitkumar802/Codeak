import sqlite3
from sqlite3 import Error
import logging

# Configure logging
logging.basicConfig(filename='library.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Library:
    def __init__(self, db_file):
        self.conn = self.create_connection(db_file)
        self.create_tables()

    def create_connection(self, db_file):
        """ Create a database connection """
        conn = None
        try:
            conn = sqlite3.connect(db_file)
            return conn
        except Error as e:
            logging.error(e)
        return conn

    def create_tables(self):
        """ Create tables if they don't exist """
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS books (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    author TEXT,
                    genre TEXT,
                    year INTEGER
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    role TEXT CHECK(role IN ('Admin', 'Member')) NOT NULL
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS transactions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    book_id INTEGER,
                    type TEXT CHECK(type IN ('borrow', 'return')) NOT NULL,
                    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(id),
                    FOREIGN KEY(book_id) REFERENCES books(id)
                )
            ''')
            self.conn.commit()
        except Error as e:
            logging.error(e)

    def add_book(self, title, author, genre, year):
        """ Add a new book to the database """
        try:
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO books (title, author, genre, year) VALUES (?, ?, ?, ?)', 
                           (title, author, genre, year))
            self.conn.commit()
            logging.info(f'Book added: {title}')
        except Error as e:
            logging.error(e)

    def display_books(self):
        """ Display all books in the library """
        try:
            cursor = self.conn.cursor()
            cursor.execute('SELECT * FROM books')
            books = cursor.fetchall()
            for book in books:
                print(book)
        except Error as e:
            logging.error(e)

    def borrow_book(self, user_id, book_id):
        """ Borrow a book """
        try:
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO transactions (user_id, book_id, type) VALUES (?, ?, ?)', 
                           (user_id, book_id, 'borrow'))
            self.conn.commit()
            logging.info(f'Book ID {book_id} borrowed by User ID {user_id}')
        except Error as e:
            logging.error(e)

    def return_book(self, user_id, book_id):
        """ Return a borrowed book """
        try:
            cursor = self.conn.cursor()
            cursor.execute('INSERT INTO transactions (user_id, book_id, type) VALUES (?, ?, ?)', 
                           (user_id, book_id, 'return'))
            self.conn.commit()
            logging.info(f'Book ID {book_id} returned by User ID {user_id}')
        except Error as e:
            logging.error(e)

    def search_books(self, keyword):
        """ Search for books by title, author, or genre """
        try:
            cursor = self.conn.cursor()
            cursor.execute('SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?', 
                           (f'%{keyword}%', f'%{keyword}%', f'%{keyword}%'))
            books = cursor.fetchall()
            for book in books:
                print(book)
        except Error as e:
            logging.error(e)

def main():
    library = Library('library.db')

    while True:
        print("\nWelcome to the Library")
        print("1. Display Books")
        print("2. Add Book")
        print("3. Borrow Book")
        print("4. Return Book")
        print("5. Search Books")
        print("6. Exit")

        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Invalid input. Please enter a number.")
            continue

        if choice == 1:
            library.display_books()
        elif choice == 2:
            title = input("Enter book title: ")
            author = input("Enter author: ")
            genre = input("Enter genre: ")
            year = int(input("Enter publication year: "))
            library.add_book(title, author, genre, year)
        elif choice == 3:
            user_id = int(input("Enter your user ID: "))
            book_id = int(input("Enter book ID to borrow: "))
            library.borrow_book(user_id, book_id)
        elif choice == 4:
            user_id = int(input("Enter your user ID: "))
            book_id = int(input("Enter book ID to return: "))
            library.return_book(user_id, book_id)
        elif choice == 5:
            keyword = input("Enter title, author, or genre to search: ")
            library.search_books(keyword)
        elif choice == 6:
            print("Exiting the library system.")
            break
        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == '__main__':
    main()
