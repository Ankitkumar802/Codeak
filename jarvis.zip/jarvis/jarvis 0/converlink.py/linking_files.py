# linking_files.py

import os
import subprocess

if __name__ == "__main__":
    # Run jarvis.py in a separate process
    jarvis_process = subprocess.Popen(['python', 'jarvis.py'])

    # Wait for jarvis.py to start
    input("Press Enter when Jarvis is ready...")

    # Run conversation.py in the main process
    os.system('python conversation.py')

    # Terminate jarvis.py when conversation.py is done
    jarvis_process.terminate()
