# conversation.py


from main import speak

def start_conversation():
    speak("Hey! I'm the second part of the conversation. What would you like to talk about?")

if __name__ == "__main__":
    start_conversation()
