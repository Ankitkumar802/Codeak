import os
import time
import webbrowser
from bs4 import BeautifulSoup
import requests
import wikipediaapi
import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import speedtest
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import math
import re
import json
import subprocess
import psutil


conversation_history = []

# Function to save conversation history to a file
def save_conversation_history():
    with open("conversation_history.json", "w") as file:
        json.dump(conversation_history, file)

# Function to load conversation history from a file
def load_conversation_history():
    global conversation_history
    if os.path.exists("conversation_history.json"):
        with open("conversation_history.json", "r") as file:
            conversation_history = json.load(file)

# Function to add an entry to the conversation history
def add_to_history(command, response):
    conversation_history.append({"command": command, "response": response})

# Function to perform PC actions
def perform_pc_action(command):
    if "shutdown" in command:
        subprocess.run(["shutdown", "/s", "/t", "1"])
    elif "restart" in command:
        subprocess.run(["shutdown", "/r", "/t", "1"])
    # Add more PC actions as needed

# Your existing functions...



def listen():
    recognizer = sr.Recognizer()
    audio = None

    with sr.Microphone() as source:
        try:
            print("Adjusting for ambient noise...")
            recognizer.adjust_for_ambient_noise(source, duration=1)  # Added a threshold of 1 second for ambient noise reduction
            print("Listening...")
            audio = recognizer.listen(source, timeout=5)  # Added a timeout of 5 seconds
        except sr.WaitTimeoutError:
            print("Listening timed out.")

    try:
        if audio:
            print("Recognizing...")
            command = recognizer.recognize_google(audio, language="en-IN")  # Specified language as English (India)
            print(f"You said: {command}")
            return command.lower()
    except sr.UnknownValueError:
        print("Sorry, could not understand audio.")
        return ""
    except sr.RequestError as e:
        print(f"Speech Recognition request failed: {e}")
        return ""

def get_exchange_rate(api_key, from_currency, to_currency):
    base_url = "https://open.er-api.com/v6/latest"
    params = {
        'apikey': api_key,
        'from': from_currency,
        'to': to_currency
    }

    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if response.status_code == 200:
            return data['rates'][to_currency]
        else:
            return None

    except Exception as e:
        print(f"Error fetching exchange rate: {str(e)}")
        return None

def convert_currency(api_key, amount, from_currency, to_currency):
    exchange_rate = get_exchange_rate(api_key, from_currency, to_currency)

    if exchange_rate is not None:
        converted_amount = amount * exchange_rate
        return f"{amount} {from_currency} is approximately {converted_amount:.2f} {to_currency}"
    else:
        return f"Error converting currency from {from_currency} to {to_currency}"

def calculate_math_expression(expression):
    try:
        result = eval(expression)
        return f"The result of {expression} is {result}"
    except Exception as e:
        return f"Error in evaluating the expression: {str(e)}"

def listen():
    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        audio = recognizer.listen(source, timeout=5)

    try:
        print("Recognizing...")
        command = recognizer.recognize_google(audio, language="en-IN")
        print(f"You said: {command}")
        return command.lower()
    except sr.UnknownValueError:
        print("Sorry, could not understand audio.")
        return ""
    except sr.RequestError as e:
        print(f"Speech Recognition request failed: {e}")
        return ""
    
def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def perform_math_calculation(command):
    # Extracting the mathematical expression from the command
    expression_match = re.search(r'\bcalculate\b|\bplus\b|\bminus\b|\bmultiply\b|\btimes\b|\bdivide\b|\bpower\b', command)
    expression_match = re.search(r'\b(calculate|plus|minus|multiply|times|divide|power)\b', command)

    if expression_match:
        expression = command[expression_match.end():].strip()
        
        try:
            result = eval(expression)
            return f"The result of {expression} is {result}"
        except Exception as e:
            return f"Error: {str(e)}"
    else:
        return "Invalid mathematical expression. Please provide a valid expression."

# Example usage:
command = "Calculate 5 plus 3"
result = perform_math_calculation(command)
print(result)

# def perform_unit_conversion(command):
#     words = command.split()
#     amount_index = words.index("convert") + 1

#     if amount_index < len(words):
#         amount = float(words[amount_index])
#         from_currency_index = words.index("from") + 1
#         to_currency_index = words.index("to") + 1

#         if from_currency_index < len(words) and to_currency_index < len(words):
#             from_currency = words[from_currency_index]
#             to_currency = words[to_currency_index]

#             if from_currency.lower() == "dollar" or from_currency.lower() == "dollars":
#                 from_currency = "USD"
#             if to_currency.lower() == "dollar" or to_currency.lower() == "dollars":
#                 to_currency = "USD"

#             return convert_currency(currency_api_key, amount, from_currency, to_currency)
#         else:
#             return "Please provide valid 'from' and 'to' currencies for conversion."
#     else:
#         return "Please provide a valid amount for conversion."
def get_cpu_usage():
    cpu_usage = psutil.cpu_percent(interval=1)
    return f"CPU Usage: {cpu_usage}%"

def get_memory_usage():
    memory = psutil.virtual_memory()
    total_memory = memory.total / (1024 * 1024 * 1024)  # Convert bytes to gigabytes
    used_memory = memory.used / (1024 * 1024 * 1024)
    return f"Memory Usage: Total: {total_memory:.2f} GB, Used: {used_memory:.2f} GB"

def get_disk_usage():
    disk_usage = psutil.disk_usage('/')
    total_disk = disk_usage.total / (1024 * 1024 * 1024)  # Convert bytes to gigabytes
    used_disk = disk_usage.used / (1024 * 1024 * 1024)
    free_disk = disk_usage.free / (1024 * 1024 * 1024)
    return f"Disk Usage: Total: {total_disk:.2f} GB, Used: {used_disk:.2f} GB, Free: {free_disk:.2f} GB"

def get_network_statistics():
    network = psutil.net_io_counters()
    bytes_sent = network.bytes_sent / (1024 * 1024)  # Convert bytes to megabytes
    bytes_received = network.bytes_recv / (1024 * 1024)
    return f"Network Statistics: Bytes Sent: {bytes_sent:.2f} MB, Bytes Received: {bytes_received:.2f} MB"

def open_website(url):
    speak(f"Opening {url}")
    webbrowser.open(url)

def search_google():
    speak("What would you like to search on Google?")
    query = listen()
    google_search_url = f"https://www.google.com/search?q={query}"
    open_website(google_search_url)

    try:
        search_results = requests.get(google_search_url)
        soup = BeautifulSoup(search_results.text, 'html.parser')
        result_divs = soup.find_all("div", class_="tF2Cxc")

        if result_divs:
            speak("Here are some search results from Google:")
            for i, result_div in enumerate(result_divs):
                result_text = result_div.get_text(strip=True)
                speak(f"Result {i + 1}: {result_text}")
        else:
            speak("Sorry, I couldn't find any search results on Google.")

    except Exception as e:
        print(f"Error fetching search results: {e}")

def search_youtube():
    speak("What would you like to search on YouTube?")
    query = listen()
    pywhatkit.playonyt(query)

def fetch_wikipedia_info(query):
    wiki_wiki = wikipediaapi.Wikipedia('en')
    page_py = wiki_wiki.page(query)
    
    if page_py.exists():
        content = page_py.text[:500]
        speak(f"Here is some information from Wikipedia: {content}")
    else:
        speak(f"Sorry, I couldn't find information about {query} on Wikipedia.")

def get_current_time():
    now = datetime.datetime.now()
    current_time = now.strftime("%H:%M:%S")
    return current_time
def check_internet_speed():
    st = speedtest.Speedtest()
    
    # Get the download speed in Megabits per second (Mbps)
    download_speed = st.download() / 1_000_000
    
    # Get the upload speed in Megabits per second (Mbps)
    upload_speed = st.upload() / 1_000_000
    
    return download_speed, upload_speed

APPLICATIONS = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "command prompt": "cmd.exe",
    "wordpad": "wordpad.exe",
    "chrome": "chrome.exe",
    "vs code": "code",
   
    "microsoft edge": "msedge.exe",
    "microsoft store": "ms-windows-store:",
}



def open_system_application(application_name):
    try:
        os.system(APPLICATIONS.get(application_name, ""))
        speak(f"Opening {application_name}")
    except Exception as e:
        speak(f"Sorry, I encountered an error while trying to open {application_name}. Error details: {str(e)}")
def save_conversation_history():
    with open("conversation_history.json", "w") as file:
        json.dump(conversation_history, file)

# Function to load conversation history from a file
def load_conversation_history():
    global conversation_history
    if os.path.exists("conversation_history.json"):
        with open("conversation_history.json", "r") as file:
            conversation_history = json.load(file)

# Function to add an entry to the conversation history
def add_to_history(command, response):
    conversation_history.append({"command": command, "response": response})

def get_public_ip():
    try:
        # Use an external service to get public IP address
        response = requests.get("https://api64.ipify.org?format=json")
        data = response.json()
        public_ip = data["ip"]
        return public_ip
    except Exception as e:
        print(f"Error: {e}")
        return None
# responses.py

greetings = [
    "Hello!",
    "Hi there!",
    "Greetings!",
    "Howdy!",
    "Hey!",
    "Hola!",
    "Salutations!",
    "Good to see you!",
    "What's up?",
]

farewells = [
    "Goodbye!",
    "Farewell!",
    "See you later!",
    "Have a great day!",
    "Until next time!",
    "Take care!",
    "Adios!",
    "Cheers!",
    "Bye now!",
]

how_are_you_responses = [
    "I'm doing well, thank you.",
    "I'm functioning at full capacity.",
    "I'm always ready to assist you.",
    "I'm great, how about you?",
    "Life is good!",
    "Fantastic, thanks for asking.",
    "Can't complain!",
    "I'm in top shape!",
    "All systems are go!",
]

positive_responses = [
    "That's fantastic!",
    "Great to hear!",
    "Awesome!",
    "Excellent!",
    "Fantastic news!",
    "Superb!",
    "You're on fire!",
    "You're unstoppable!",
    "Bravo!",
]

negative_responses = [
    "I'm sorry to hear that.",
    "That's tough, I'm here for you.",
    "Hang in there, things will get better.",
    "I'm here to support you.",
    "Tomorrow is a new day.",
    "Take a deep breath, you've got this.",
    "I believe in your resilience.",
    "Sending positive vibes your way.",
    "You're stronger than you think.",
]

compliments = [
    "You're doing an amazing job!",
    "You're incredibly talented.",
    "Your efforts are truly appreciated.",
    "You're a valuable part of the team.",
    "Keep up the good work!",
    "You've got a great attitude!",
    "Your dedication is inspiring.",
    "You're making a difference.",
    "Impressive work!",
]

encouragements = [
    "You've got this!",
    "Believe in yourself.",
    "Keep pushing forward.",
    "Success is just around the corner.",
    "Stay positive and focused.",
    "Embrace the challenges, they make you stronger.",
    "Your hard work will pay off.",
    "Take it one step at a time.",
    "You're on the path to success.",
]

random_responses = [
    "Interesting!",
    "Tell me more.",
    "I see.",
    "Fascinating!",
    "That's intriguing.",
    "Hmm, I need to think about that.",
    "Curious indeed.",
    "I appreciate your perspective.",
    "Let's explore that further.",
]

# Add more categories and responses as needed

 
def send_email():
    speak("From which email account would you like to send the email?")
    sender_email = listen()

    speak("To whom would you like to send the email?")
    to_email = listen()

    speak("What is the subject of the email?")
    subject = listen()

    speak("What message would you like to include in the email?")
    body = listen()

    # Your email credentials
    email_credentials = {
        "ankitkumar@777768@gmail.com": "Ankitkumar@1234",
        "anashk7768@gmail.com": "Ankitkumar@1234",
        # Add more email accounts as needed
    }

    if sender_email in email_credentials:
        email_address = sender_email
        email_password = email_credentials[sender_email]

        # Email server setup (for Gmail)
        smtp_server = "smtp.gmail.com"
        smtp_port = 587

        # Create the email message
        message = MIMEMultipart()
        message["From"] = email_address
        message["To"] = to_email
        message["Subject"] = subject

        # Attach the body of the email
        message.attach(MIMEText(body, "plain"))

        # Establish a connection with the SMTP server
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            # Log in to the email account
            server.starttls()  # Use TLS (Transport Layer Security)
            server.login(email_address, email_password)

            # Send the email
            server.sendmail(email_address, to_email, message.as_string())

        speak("Email sent successfully!")
    else:
        speak(f"Sorry, I don't have the credentials for {sender_email}.")

# Your existing code...
        
import requests

def get_weather(api_key, city):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        'q': city,
        'appid': api_key,
        'units': 'metric'  # You can change units to 'imperial' for Fahrenheit
    }

    try:
        response = requests.get(base_url, params=params)
        data = response.json()

        if response.status_code == 200:
            weather_description = data['weather'][0]['description']
            temperature = data['main']['temp']
            humidity = data['main']['humidity']
            wind_speed = data['wind']['speed']

            result = f"Weather in {city}: {weather_description}. Temperature: {temperature}°C. Humidity: {humidity}%. Wind Speed: {wind_speed} m/s."
            return result
        else:
            return f"Error: Unable to fetch weather information for {city}. Status Code: {response.status_code}"

    except Exception as e:
        return f"Error: {str(e)}"

# Existing code...

def send_whatsapp_message():
    speak("To whom would you like to send a WhatsApp message?")
    recipient_name = listen()

    # Replace this dictionary with your contact details
    contact_details = {
        'ankit': '+918302293157',
        'gaurav': '+919608676564',
        'saurab': '+91765302836'
        # Add more contacts as needed
    }

    print(f"Recipient name: {recipient_name}")
    recipient_phone_number = contact_details.get(recipient_name.lower())
    print(f"Recipient phone number: {recipient_phone_number}")

    if recipient_phone_number:
        speak(f"Okay! What message would you like to send to {recipient_name}?")
        message_to_send = listen()
        now = datetime.datetime.now()

        # Adjusting the call time to be greater than the wait time
        call_time = datetime.datetime(now.year, now.month, now.day, now.hour, now.minute + 1, 0)
        wait_time = datetime.timedelta(minutes=2)  # Adjust as needed

        left_time = call_time - now
        if left_time.total_seconds() < wait_time.total_seconds():

            speak("Please wait a bit before sending another message.")
        else:
            wait_time = 5  # You can adjust this value based on your needs
            pywhatkit.sendwhatmsg(recipient_phone_number, message_to_send, call_time.hour, call_time.minute, wait_time)

            speak(f"Message sent to {recipient_name} successfully!")
    else:
        speak(f"Sorry, I don't have the contact details for {recipient_name}.")



# Existing code...

# Existing code...

# Your existing code...
if __name__ == "__main__":
    speak("Hello! I am Jarvis. How can I assist you today?")

    while True:
        command = listen()
        add_to_history(command, "Processing...")

        if "shutdown" in command or "restart" in command:
            perform_pc_action(command)
            speak(f"Okay, {command.capitalize()} initiated.")
        elif "jarvis go to sleep" in command:
            speak("Okay, I will wait for your next command.")
            while True:
                resume_command = listen()
                if "wakeup jarvis" in resume_command:
                    speak("Resuming. What can I do for you now?")
                    break
                time.sleep(1)
        elif "wakeup jarvis" in command:
            speak("I am not currently waiting. Please provide a valid command.")
        elif "open" in command:
            for app_name, app_path in APPLICATIONS.items():
                if app_name in command:
                    open_system_application(app_name)
                    break
        elif "stop" in command:
            speak("Goodbye!")
            break
        elif "hello" in command:
            speak("Hello! How can I help you?")
        elif "open google" in command:
            open_website("https://www.google.com")
            speak("Opening Google")
        elif "search google" in command:
            search_google()
        elif "open youtube" in command:
            open_website("https://www.youtube.com")
            search_youtube()
        elif "fetch information from wikipedia about" in command:
            query = command.replace("fetch information from wikipedia about", "").strip()
            fetch_wikipedia_info(query)
        elif "send whatsapp message" in command:
            send_whatsapp_message()
        elif "send email" in command:
            send_email()
        elif "what is the time" in command:
            current_time = get_current_time()
            speak(f"The current time is {current_time}")
        elif "check internet speed" in command:
            speak("ok sir i checked internet speed")
            download_speed, upload_speed = check_internet_speed()
            speak(f"Download Speed: {download_speed:.2f} Mbps, Upload Speed: {upload_speed:.2f} Mbps")
            print(f"Download Speed: {download_speed:.2f} Mbps, Upload Speed: {upload_speed:.2f} Mbps")
        elif "weather" in command:
            # Extracting the city from the command
            words = command.split()
            city_index = words.index("weather") + 1
            # Check if the city name is present
            if city_index < len(words):
                city = " ".join(words[city_index:])
                api_key = "c526e3a4a325d2ddeb20d911a3cce526"
                weather_info = get_weather(api_key, city)
                print(weather_info)
                speak(weather_info)
            else:
                speak("Please provide a valid city name.")
        elif "calculate" in command or any(keyword in command for keyword in ["plus", "minus", "multiply", "times", "divide", "power"]):
            result = perform_math_calculation(command)
            speak(result)
            print(result)
        else:
            speak("Sorry, I didn't understand. Can you please repeat?")

        # Save conversation history after each interaction
        save_conversation_history()

    # Retrieve and print system information
    print(get_cpu_usage())
    print(get_memory_usage())
    print(get_disk_usage())
    print(get_network_statistics())







